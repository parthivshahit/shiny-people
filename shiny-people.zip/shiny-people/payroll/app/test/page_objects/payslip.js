module.exports = {
    elements: {
        payslipForm: by.name('payslipForm'),
        employeeName: by.css('form h4'),
        annualIncome: by.xpath('//td[contains(text(), "Annual Income")]/following-sibling::td'),
        super: by.xpath('//td[contains(text(), "Super")]/following-sibling::td'),
		generatePayslipButton: by.css('button.btn-primary'),
		daletePaymentButton: by.xpath('/html/body/my-app/div/payments/div/div/div[4]/input[1]'),
		viewPayments: by.xpath('/html/body/my-app/div/payments/div/div/div[4]/input[2]')
    },
};