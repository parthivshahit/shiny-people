const expect = require('chai').expect;

module.exports = function () {

    this.When(/^I generate a payslip for a new employee$/, function () {
        return helpers.loadPage(page.payroll.url)
            .then( () => {
                return page.payroll.enterNewEmployeeDetails("John", "Snow", "81900", "9")
        })
    });

    this.Then(/^I should see the payslip summary page$/, function () {
        return driver.wait(until.elementsLocated(page.payslip.elements.payslipForm), 20000)
            .then( () => {
                driver.findElement(page.payslip.elements.employeeName).getText()
                .then(t => {
                    expect(t).to.be.eql("John Snow");
                })
            })
            .then( () => {
                driver.findElement(page.payslip.elements.annualIncome).getText()
                    .then(t => {
                        expect(t).to.be.eql("$81,900.00");
                })
            })
            .then( () => {
                driver.findElement(page.payslip.elements.super).getText()
                    .then(t => {
                        expect(t).to.be.eql("$614.00");
                })
            });
    });
	
	this.Then(/^I click on Pay button to make payment$/, function() {
		driver.findElement(page.payslip.elements.generatePayslipButton).click()
	});
	
	
	this.When(/^I click on view button$/, function() {
		 return helpers.loadPage(page.payroll.url)
			.then( () => {
		  return driver.wait(until.elementsLocated(page.payslip.elements.viewPayments),10000)
			})
	});
	this.Then(/^I should view payment summary page$/, function() {
		
		 driver.findElement(page.payslip.elements.viewPayments).click()
		 
		});

	this.When(/^I click on Delete button$/, function () {
        return helpers.loadPage(page.payroll.url)
            .then( () => {
				console.log('indelete')
            return driver.wait(until.elementsLocated(page.payslip.elements.daletePaymentButton), 20000)
        })
    });
	
	this.Then(/^It should delete a payment$/, function() {
		
			 driver.findElement(page.payslip.elements.daletePaymentButton).click()
		});
		
	
};