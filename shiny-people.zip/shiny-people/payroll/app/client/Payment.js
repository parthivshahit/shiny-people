"use strict";
var Payment = (function () {
    function Payment() {
    }
    return Payment;
}());
exports.Payment = Payment;
//# sourceMappingURL=Payment.js.map