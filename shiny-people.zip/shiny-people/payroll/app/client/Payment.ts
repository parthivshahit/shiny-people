export class Payment {
    firstName: string;
    lastName: string;
    annualSalary: number;
    superRate: number;
    payPeriod: Date;
    grossIncome: number;
    incomeTax: number;
    netIncome: number;
    super: number;
    pay: number;
    payPeriodMonth: string;
}